import webbrowser
# create the class named Movie
# first letter of the class_named must be capital


class Movie():
    '''class describe the attributes of an movie
    Note:
        Do not include the `self` parameter in the ``Args`` section.
    Args(Arguments):
        movie_title: title of the movie
        movie_storyline: storyline of the movie
        poster_image: poster of the movie
        movie_trailer: link of the movie trailer
    methods:
        show_trailer: show the trailer of the movie'''
    def __init__(self, movie_title, movie_storyline,
                 poster_image, movie_trailer):
        # __init__ function is a constructor for the class Movie
        '''__init__ function initialize or creates space in memory to
        remember details of the movies likelike title, stroyline
        poster_image, trailer
        INPUTS: takes in information or arguments first is self
                (means the instace being created)
                and the thinks that is to be store in the instance
        OUTPUT: store the information in the memory by creating the
                space in memory'''
        self.title = movie_title
        self.storyline = movie_storyline
        self.poster_image_url = poster_image
        self.trailer_youtube_url = movie_trailer
    # create the function named show_trailer that opens the movie trailer.
    # in this project it is not need.
    # created it show how we can access the single instance variable.

    def show_trailer(self):
        '''opens the trailer link in browser that is stored in the instance
            INPUT: takes in the instance of the class Movie
            OUTPUT: open the link that is stored in the that instance'''
        webbrowser.open(self.trailer_youtube_url)
