movies webpage

DOWNLOAD
	-First download the the zip file uploaded by me and unzip the file 

NOTES
	May sure that the files named fresh_tomatoes.py, media.py, entertainment_center.py are in the 'same folder'

HOW TO RUN THE CODE USING IDLE?
	- Open the file "entertainment_center.py" in IDLE
	- Click on 'run'

HOW TO RUN THE CODE USING ANACONDA?
 	- If you want to run the program in anaconda then open the anaconda prompt and go the folder using the command 'cd folder_name'.
	- If the program is in the sub folder then use the command 'cd folder_name' until you reach the required folder.
	- Then use the command ipython entertainment_center.py to run and to get the output
	
 