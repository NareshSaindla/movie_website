# import the require file that are required to run the programe

import fresh_tomatoes
import media
# create the mutiple instances of the class Movie in the media.py file
# we have to pass the required arguments link while creating the instances
# arguments are movie_title, movie_storyline, poster_image, movie_trailer

rangasthalam = media.Movie(
    "Rangasthalam", "A boy saves the village from villan",
    "http://www.idlebrain.com/images5/rangasthalam-poster8.jpg",
    "https://www.youtube.com/watch?v=1Drha8HZN_c")

bharath_ane_nenu = media.Movie(
    "Bharath Ane Nenu", "Bharath changes the situation in the states",
    "http://www.idlebrain.com/images5/bharatanenenu-poster4.jpg",
    "https://www.youtube.com/watch?v=IvSoRWkaKn4")

hacksaw_ridge = media.Movie(
    "Hacksaw Ridge",
    "The true story of Pfc. Desmond T.Doss(Andrew Garfield)",
    "https://movieposters2.com/images/1439169-b.jpg",
    "https://www.youtube.com/watch?v=s2-1hz1juBI")

leap = media.Movie(
    "Leap!(Ballerina)",
    "A boy and the girl escape from orphane to achive there dreams.",
    "http://img.moviepostershop.com/leap-movie-poster-2017-1020777355.jpg",
    "https://www.youtube.com/watch?v=sMpmYXi94Jo")

jungle = media.Movie(
    "Jungle",
    "True story of Greg McLean, how we survived in jungle",
    "https://virily.com/wp-content/uploads/2017/11/jungle.jpg",
    "https://www.youtube.com/watch?v=RI_Iz3-88Fw")

zootopia = media.Movie(
    "Zootopia",
    "how judy saved the city zootopia",
    "https://image.tmdb.org/t/p/original/1YzLAWykXzZhydoGJCqoVQ0gVyC.jpg",
    "https://www.youtube.com/watch?v=CzvH6_e2a-U")

wall_e = media.Movie(
    "Wall.E",
    "wall.e an waste collection robot helps eve to commplete its mission",
    "http://www.pixartalk.com/wp-content/uploads/2009/06/wallefinal.jpg",
    "https://www.youtube.com/watch?v=alIq_wG9FNk")

big_hero_6 = media.Movie(
    "Big Hero 6",
    "Hiro, a robotics prodigy,takes avenge of his brother's death.",
    "http://infobandung.co.id/wp-content/uploads/2014/11/big-hero-6-a.jpg",
    "https://www.youtube.com/watch?v=d2S8D_SCAJY")

run_raja_run = media.Movie(
    "Run Raja Run",
    "how raja succeeded in his love story",
    "http://www.idlebrain.com/images5/firstlook-runrajarun.jpg",
    "https://www.youtube.com/watch?v=pdLh89YMyJI")
# create the list of instance that are created
movies = [rangasthalam, bharath_ane_nenu, hacksaw_ridge, leap, jungle,
          zootopia, wall_e, big_hero_6, run_raja_run]

# calling open_movies_page function in fresh_tomatoes.py file
'''open_movies_page function in fresh_tomatoes.py file will take list of
    movies as arguments and gives the server side website
INPUT: list movies
OUTPUT: A website that contain the movies that are in the list
        provided as an argument'''
fresh_tomatoes.open_movies_page(movies)
